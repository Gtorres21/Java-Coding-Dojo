package com.giovanni.daikichipathvar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichipathvarApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichipathvarApplication.class, args);
	}

}
