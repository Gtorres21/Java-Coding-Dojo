package com.giovanni.zookeepertwo;

import com.giovanni.zookeepertwo.models.Bat;


public class ZooKeeperTwoApplication {


	public static void main(String[] args) {

		
	Bat batman1 = new Bat();
	batman1.displayEnergy();
	batman1.attackTown();
	batman1.attackTown();
	batman1.attackTown();
	batman1.eatHumans();
	batman1.eatHumans();
	batman1.fly();
	batman1.displayEnergy();	
	
	}

}
