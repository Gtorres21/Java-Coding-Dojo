package com.giovanni.dojosandninjas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoandninjasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoandninjasApplication.class, args);
	}

}
