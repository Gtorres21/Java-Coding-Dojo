package com.giovanni.dojosandninjas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoandninjasApplicationTests {

	@Test
	void contextLoads() {
	}

}
